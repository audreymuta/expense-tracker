-- Create Database
CREATE DATABASE expense_db;

--auth Table. This is the most important table in the database. It will store the user information and the reason for the user to use this app. The reason can be either 'income' or 'expense'. The reason is used to determine the type of transaction the user is making.
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    reason VARCHAR(10) NOT NULL,
    
);

-- Transactions Table is optional as java script will handle the transactions but you can create it if you want to store the transactions in the database
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('income', 'expense') NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    category VARCHAR(50) NOT NULL,
    date DATE NOT NULL,
    note TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Categories Table java script will handle the categories but you can create it if you want to store the categories in the database
-- Categories Table
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(50) NOT NULL,
    type ENUM('income', 'expense') NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
