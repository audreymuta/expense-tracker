# Expense Tracker

This is a simple web-based expense tracker built with PHP and MySQL. It allows users to REGISTER FIRST first and be redirected to the main app (index.html afte 5s) where the UI displays expenses, categorize them, and view their spending history. Users information is stored in expense_db database in auth table

## Features:

- Add, edit, generate report(csv, pdf & TEXT) and delete expenses
- Categorize expenses
- View expenses by date and category
- Total spending summary
- Javascript is handingling the UI whlst php is storing users accessing the app and the reason.


## Technologies Used:

- PHP backend connection and authentication
- MySQL
- HTML/CSS, Bootstrap
- JavaScript 

## Setup Instructions

1.download the repository, extract files, ensure Xamp is on your local machine and folder expense tracker in xamp/ htdocs.
2.Stand the register.html, its connected to the database expense_db and after registerations, you will be redirected to the index.html (main webapp). Its fully functioning.

kindly note that you can clone the project too.

```bash
git clone https://github.com/your-username/expense-tracker.git
