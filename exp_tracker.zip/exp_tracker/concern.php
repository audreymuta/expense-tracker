<?php
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['name'], $_POST['address'], $_POST['concern'])) {
        $conn = new mysqli("localhost", "root", "", "expense_db");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $name    = $conn->real_escape_string($_POST['name']);
        $address = $conn->real_escape_string($_POST['address']);
        $concern = $conn->real_escape_string($_POST['concern']);

        $sql = "INSERT INTO user_concerns (name, address, concern)
                VALUES ('$name', '$address', '$concern')";

        if ($conn->query($sql) === TRUE) {
            $message = "✅ Concern submitted successfully!";
        } else {
            $message = "❌ Error: " . $conn->error;
        }

        $conn->close();
    } else {
        $message = "❌ Please fill in all fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Concern Submission</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
</head>
<body class="bg-light">
  <div class="container mt-5">
    <div class="alert <?php echo strpos($message, '✅') !== false ? 'alert-success' : 'alert-danger'; ?>">
      <?php echo $message; ?>
    </div>
    <a href="concern.html" class="btn btn-primary">Back to Concern Form</a>
  </div>
</body>
</html>
