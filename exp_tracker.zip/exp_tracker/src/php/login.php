<?php
// login.php
header("Content-Type: application/json");
$data = json_decode(file_get_contents("php://input"), true);

// Connect to DB
$conn = new mysqli("localhost", "root", "", "expense_db");
if ($conn->connect_error) {
    http_response_code(500);
    echo "Database connection failed";
    exit();
}

$username = $conn->real_escape_string($data['username']);
$password = $data['password'];

// Check if user exists
$sql = "SELECT * FROM auth WHERE username = '$username'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();

    if (password_verify($password, $user['password'])) {
        // IMPORTANT: echo exactly "success" for JS check
        echo "success";
    } else {
        http_response_code(401);
        echo "Incorrect password.";
    }
} else {
    http_response_code(404);
    echo "User not found.";
}

$conn->close();
?>


