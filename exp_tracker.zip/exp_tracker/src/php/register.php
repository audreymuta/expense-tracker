<?php
// register.php
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

$conn = new mysqli("localhost", "root", "", "expense_db");
if ($conn->connect_error) {
    http_response_code(500);
    echo "Database connection failed.";
    exit();
}

$username = $conn->real_escape_string($data['username']);
$email = $conn->real_escape_string($data['email']);
$password = password_hash($data['password'], PASSWORD_DEFAULT);
$reason = $conn->real_escape_string($data['reason']);

// Check if username or email already exists
$check = $conn->query("SELECT id FROM auth WHERE username = '$username' OR email = '$email'");
if ($check && $check->num_rows > 0) {
    http_response_code(409);
    echo "Username or email already exists.";
    exit();
}

// Insert new user
$sql = "INSERT INTO auth (username, email, password, reason)
        VALUES ('$username', '$email', '$password', '$reason')";

if ($conn->query($sql) === TRUE) {
    echo "Registration successful!";
} else {
    http_response_code(500);
    echo "Error: " . $conn->error;
}

$conn->close();
?>
