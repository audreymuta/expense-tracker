document.getElementById('registerForm').addEventListener('submit', function (e) {
  e.preventDefault();

  const username = document.getElementById('registerUsername').value;
  const email = document.getElementById('registerEmail').value;
  const password = document.getElementById('registerPassword').value;
  const reason = document.getElementById('reason').value;

  fetch('register.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, email, password, reason })
  })
    .then(res => res.text())
    .then(data => {
      if (data.includes("successful")) {
        // Store username for next page
        localStorage.setItem("registeredUsername", username);

        // Create message
        const messageBox = document.createElement("p");
        messageBox.textContent = `Welcome, ${username}! Sign up successful. Connecting you to Expense Tracker...`;
        messageBox.style.color = "green";
        messageBox.style.fontWeight = "bold";
        messageBox.style.marginTop = "15px";

        document.querySelector(".auth-container").appendChild(messageBox);

        // Redirect after 5 seconds
        setTimeout(() => {
          window.location.href = "index.html";
        }, 5000);
      } else {
        alert(data);
      }
    })
    .catch(err => {
      alert('Error during registration');
      console.error(err);
    });
});
