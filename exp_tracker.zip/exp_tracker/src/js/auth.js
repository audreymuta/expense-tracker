document.getElementById('loginForm')?.addEventListener('submit', function (e) {
  e.preventDefault();

  const username = document.getElementById('loginUsername').value;
  const password = document.getElementById('loginPassword').value;

  fetch('login.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  })
    .then(res => res.text())
    .then(data => {
      console.log("Login response:", data); 

      if (data.includes("success")) {
        localStorage.setItem("registeredUsername", username);

        const messageBox = document.createElement("p");
        messageBox.textContent = `Welcome, ${username}! Logging you in...`;
        messageBox.style.color = "green";
        messageBox.style.fontWeight = "bold";
        messageBox.style.marginTop = "15px";
        document.querySelector(".auth-container").appendChild(messageBox);

        setTimeout(() => {
          window.location.href = "index.html";
        }, 5000);
      } else {
        alert(data);
      }
    })
    .catch(err => {
      alert('Login failed');
      console.error(err);
    });
});

