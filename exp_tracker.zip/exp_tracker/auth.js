document.getElementById("registerForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const username = document.getElementById("registerUsername").value;
  const email = document.getElementById("registerEmail").value;
  const password = document.getElementById("registerPassword").value;
  const reason = document.getElementById("reason").value;

  fetch("register.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, email, password, reason })
  })
    .then(res => res.json())
    .then(data => {
      if (data.status === "success") {
        // Redirect to index.html on successful registration
        window.location.href = "index.html";
      } else {
        alert(data.message || "Registration failed");
      }
    })
    .catch(err => {
      alert("Something went wrong.");
      console.error("Error:", err);
    });
});
