
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connect to DB
$conn = new mysqli("localhost", "root", "", "expense_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $conn->real_escape_string(trim($_POST['username']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $reason = $conn->real_escape_string(trim($_POST['reason']));

    // Check if username/email exists
    $check = $conn->query("SELECT id FROM auth WHERE username = '$username' OR email = '$email'");
    if ($check && $check->num_rows > 0) {
        echo "
        <html>
          <body style='text-align:center; padding-top:50px; font-family:sans-serif;'>
            <h3 style='color:red;'>Username or email already exists.</h3>
            <a href='register.html'>Back to Register</a>
          </body>
        </html>";
        exit();
    }

    // Insert into DB
    $sql = "INSERT INTO auth (username, email, password, reason) 
            VALUES ('$username', '$email', '$password', '$reason')";

    if ($conn->query($sql) === TRUE) {
        echo "
        <html>
          <head>
            <meta http-equiv='refresh' content='3;url=auth.html'>
          </head>
          <body style='text-align:center; padding-top:50px; font-family:sans-serif;'>
            <h2>Registration successful!</h2>
            <p>Redirecting to login page...</p>
          </body>
        </html>";
    } else {
        echo "Error: " . $conn->error;
    }
}

$conn->close();
?>


