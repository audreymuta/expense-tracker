<?php
session_start();

// Enable error reporting (optional for debugging)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// DB connection
$conn = new mysqli("localhost", "root", "", "expense_db");
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $conn->real_escape_string(trim($_POST['username']));
    $password = $_POST['password'];

    // Look for the user
    $sql = "SELECT * FROM auth WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            // Successful login
            $_SESSION['username'] = $username;

            // Redirect to index.html
            header("Location: index.html");
            exit();
        } else {
            echo "<p style='color:red; text-align:center;'>Incorrect password.</p><p style='text-align:center;'><a href='auth.html'>Try again</a></p>";
        }
    } else {
        echo "<p style='color:red; text-align:center;'>User not found.</p><p style='text-align:center;'><a href='auth.html'>Try again</a></p>";
    }
}

$conn->close();
?>







